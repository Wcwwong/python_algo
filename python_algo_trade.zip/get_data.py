# insert your API key here
API_KEY = '2VzGLKG4ajn6srWCeRFgXxH386F'

# import ccxt
import time
import pandas as pd
import datetime
from pprint import pprint
import requests
from io import StringIO

pd.set_option('display.max_rows', None)
pd.set_option('display.max_columns', None)
pd.set_option('display.width', 1000)

#################

PORTFOLIO_FILE = 'portfolio.csv'
RESOLUTION = '24h'
PRICE_SYMBOL = 'BTC'

SINCE = int(time.mktime(datetime.datetime(2022, 3, 1).timetuple()))
UNTIL = int(time.time())

#################


def get_gn_data(path, symbol): # get glassnode data

    # print('Requesting from', path, '...')
    res = requests.get(path,
        params={"a": symbol, "s": SINCE, "u": UNTIL, "api_key": API_KEY, "i": RESOLUTION})
    df_value = pd.read_json(StringIO(res.text), convert_dates=['t'])
    # print(res.status_code, res.reason)

    price_path = 'https://api.glassnode.com/v1/metrics/market/price_usd_close'
    # print('Requesting from', price_path, '...')
    res = requests.get(price_path,
        params={"a": PRICE_SYMBOL, "s": SINCE, "u": UNTIL, "api_key": API_KEY, "i": RESOLUTION})
    df_price = pd.read_json(StringIO(res.text), convert_dates=['t'])
    # print(res.status_code, res.reason)

    # print(df_value)
    # print(df_price)

    df = pd.merge(df_value, df_price, how='inner', on='t')
    df = df.rename(columns={'v_x': 'value', 'v_y': 'price'})

    return df


pf = pd.read_csv(PORTFOLIO_FILE)
pf = pf[['Path1', 'Path2', 'Underlying', # 'Resolution',
        ]]
pf['path'] = 'https://api.glassnode.com/v1/metrics/' + pf['Path1'] + '/' + pf['Path2']


### get data ###
while True:

    # if datetime.datetime.now().hour == 8 and datetime.datetime.now().minute == 0:
    if datetime.datetime.now().second == 0:  # every minute
    # if datetime.datetime.now().second % 15 == 0:  # every :15 seconds
        print(datetime.datetime.now())

        try:
            for index, row in pf.iterrows():
                df = get_gn_data(row['path'], row['Underlying'])

                df_new = pd.DataFrame(df, columns=['t', 'value', 'price'])
                df_new = df_new[['t', 'value', 'price']]

                csv_suffix = '-'.join([row['Path1'], row['Path2'], row['Underlying'], RESOLUTION])
                csv_path = 'gn_data_' + csv_suffix + '.csv'

                try:
                    df_old = pd.read_csv(csv_path)
                    df_new = pd.concat([df_old, df_new]).drop_duplicates(subset=['t']).reset_index(drop=True)
                    df_new = df_new[['t', 'value', 'price']]
                except:
                    pass

                df_new.to_csv(csv_path)

                time.sleep(1)

        except:
            pass