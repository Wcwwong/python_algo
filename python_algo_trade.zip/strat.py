import pandas as pd
import numpy as np
import datetime
import time

pd.set_option('display.max_rows', None)
pd.set_option('display.max_columns', None)
pd.set_option('display.width', 1000)

#################

PORTFOLIO_FILE = 'portfolio.csv'

# weight of each strategy
# WEIGHTS = [0.2, 0.3, 0.3, 0.2]
WEIGHTS = None # if WEIGHTS array is not given, weights are assumed to be even

#################

STRATEGY_MAPPING = {
    'long': 'long',
    'long only': 'long',
    'short': 'short',
    'short only': 'short',
    'longshort': 'longshort',
    'long+short': 'longshort',
    'long-short': 'longshort',
    'long/short': 'longshort',
}

DIRECTION_MAPPING = {
    'mm': 'mm',
    'momentum': 'mm',
    'rev': 'rev',
    'reversal': 'rev',
}

#################

### signal ###
# model: madiff, bband, ...
# strategy: mm/rev
# direction: long, longshort
def strat(gn_data_path, model, strategy, direction, x, y):
    if model not in ['madiff', 'bband']:
        print('*** Model ' + model + ' not supported.')
        exit(1)

    if strategy not in ['mm', 'rev']:
        print('*** Strategy ' + strategy + ' not supported.')
        exit(1)

    if direction not in ['long', 'short', 'longshort']:
        print('*** Direction ' + direction + ' not supported.')
        exit(1)

    df = pd.read_csv(gn_data_path)

    df['pct_change'] = df['price'].pct_change()

    df['ma'] = df['value'].rolling(x).mean()
    df['sd'] = df['value'].rolling(x).std()
    df['z'] = (df['value'] - df['ma']) / df['sd']

    if model == 'madiff':
        if strategy == 'mm':
            if direction == 'long':
                df['pos'] = np.where(df['value'] > (df['ma'] * (1 + y)), 1, 0)
            if direction == 'short':
                df['pos'] = np.where(df['value'] < (df['ma'] * (1 - y)), -1, 0)
            if direction == 'longshort':
                df['pos'] = np.where(df['value'] < (df['ma'] * (1 - y)), -1,
                                     np.where(df['value'] > (df['ma'] * (1 + y)), 1, 0))
        if strategy == 'rev':
            if direction == 'long':
                df['pos'] = np.where(df['value'] < (df['ma'] * (1 - y)), 1, 0)
            if direction == 'short':
                df['pos'] = np.where(df['value'] > (df['ma'] * (1 + y)), -1, 0)
            if direction == 'longshort':
                df['pos'] = np.where(df['value'] < (df['ma'] * (1 - y)), 1,
                                     np.where(df['value'] > (df['ma'] * (1 + y)), -1, 0))

    if model == 'bband':
        if strategy == 'mm':
            if direction == 'long':
                df['pos'] = np.where(df['z'] > y, 1, 0)
            if direction == 'short':
                df['pos'] = np.where(df['z'] < -y, -1, 0)
            if direction == 'longshort':
                df['pos'] = np.where(df['z'] > y, 1, np.where(df['z'] < -y, -1, 0))
        if strategy == 'rev':
            if direction == 'long':
                df['pos'] = np.where(df['z'] < -y, 1, 0)
            if direction == 'short':
                df['pos'] = np.where(df['z'] > y, -1, 0)
            if direction == 'longshort':
                df['pos'] = np.where(df['z'] > y, -1, np.where(df['z'] < -y, 1, 0))

    df['pos'] = np.where(df['z'] > y, 1, 0)
    # df['pos'] = np.where(df['z'] > y, 1, np.where(df['z'] < -y, -1, 0))

    df['pos_t-1'] = df['pos'].shift(1)
    df['trade'] = abs(df['pos'] - df['pos_t-1'])
    df['cost'] = df['trade'] * 0.05/100
    df['pnl'] = df['pos_t-1'] * df['pct_change'] - df['cost']
    df['cumu'] = df['pnl'].cumsum()

    pos = df['pos'].iloc[-1]

    print(df.tail(5))

    return pos


def weighting(pos_arr, weights=None):

    if weights is None:
        pos = np.average(pos_arr)
    elif np.isnan(weights).any():
        print('*** NaN found in weights array')
        exit(1)
    else:
        try:
            pos = np.average(pos_arr, weights)
        except TypeError as e:
            print('*** weights array does not contain the same number of elements as pos_arr')
            exit(1)

    print('signal', pos)

    try:
        df_signal = pd.read_csv('signal.csv')
    except:
        df_signal = pd.DataFrame(columns=['dt', 'pos'])

    now = datetime.datetime.now()
    # df_signal = df_signal.append(pd.Series([now, pos], index=['dt', 'pos']), ignore_index=True)
    df_signal = pd.concat([df_signal, pd.Series([now, pos], index=['dt', 'pos']).to_frame().T], ignore_index=True)
    df_signal = df_signal[['dt', 'pos']]
    print(df_signal)
    df_signal.to_csv('signal.csv')

    return pos


#################

pf = pd.read_csv(PORTFOLIO_FILE)

strats_list = []

for i in range(len(pf)):
    path = 'gn_data_' + '-'.join([pf.loc[i, 'Path1'],
                                  pf.loc[i, 'Path2'],
                                  pf.loc[i, 'Underlying'],
                                  pf.loc[i, 'Resolution']]) + '.csv'
    model = pf.loc[i, 'Model'].lower()
    strategy = DIRECTION_MAPPING[pf.loc[i, 'mm/rev'].lower()]
    direction = STRATEGY_MAPPING[pf.loc[i, 'Strat'].lower()]
    x = pf.loc[i, 'Window']
    y = pf.loc[i, 'Threshold']
    # weight = pf.loc[i, 'Weight']

    strats_list.append(pd.Series([path, model, strategy, direction, x, y],
                                 index=['path', 'model', 'strategy', 'direction', 'x', 'y']))

strats_df = pd.DataFrame(strats_list)

# print(strats_df)
# time.sleep(1000)

strat_vectorized = np.vectorize(strat)

while True:
    # if datetime.datetime.now().second == 5:
    if datetime.datetime.now().second % 15 == 0:
        strats_df['pos'] = strat_vectorized(strats_df['path'],
                                            strats_df['model'],
                                            strats_df['strategy'],
                                            strats_df['direction'],
                                            strats_df['x'],
                                            strats_df['y'])
        print(strats_df)
        pos_arr = strats_df['pos'].to_numpy()
        weighting(pos_arr, WEIGHTS)
        time.sleep(1)
